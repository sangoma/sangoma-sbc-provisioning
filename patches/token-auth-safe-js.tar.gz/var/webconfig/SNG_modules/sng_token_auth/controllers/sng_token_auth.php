<?php
/** vim: set tabstop=4 softtabstop=4 shiftwidth=4 textwidth=80 smarttab expandtab: **/
/** coding: utf-8: **/
/*
 * Copyright (C) 2012  Sangoma Technologies Corp.
 * All Rights Reserved.
 *
 * Author(s)
 * your name <your_name@sangoma.com>
 *
 * This code is Sangoma Technologies Confidential Property.
 * Use of and access to this code is covered by a previously executed
 * non-disclosure agreement between Sangoma Technologies and the Recipient.
 * This code is being supplied for evaluation purposes only and is not to be
 * used for any other purpose.
*/
/**
 * Network Config wrapper page
 * @author Santiago Tramoyeres Cuesta <scuesta@sangoma.com>
 *         
 */
if (!defined('BASEPATH')) exit('No direct script access allowed');
require_once ('application/helpers/safe_helper.php');
require_once ('application/controllers/Safe_CI_Controller.php');

class Sng_token_auth extends Safe_CI_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    private function valid($token){
        $module = $this->_the_app->module('rest');
        $apikeys = $module->get_aggregate_objects('apikey');
        foreach($apikeys as $id => $apikey){
            $key = $apikey->get_data_value('key');
            if(WebIsValidToken($token,$key))
                return true;
        }
        return false;
    }

    private function get_user(){
        $module = $this->_the_app->module('system');
        $users = $module->get_aggregate_objects('user');
        foreach($users as $name => $user){
            if(strtolower($user->get_data_value('access'))=='enable' &&
                    strtolower($user->get_data_value('sudoer'))=='enable')
                return $name;
        }
        return 'root';
    }

    public function index(){
        if(preg_match('#(.+?)/\?token=(.+)#',$_SESSION['referrer'],$match) && $this->valid($match[2])){
            WebForwardPage($match[1].'/?local_token='.WebGenerateToken(WebGetLocalToken()).'&reserved_user='.$this->get_user());
        }else
            WebForwardPage('/');
    }
}
