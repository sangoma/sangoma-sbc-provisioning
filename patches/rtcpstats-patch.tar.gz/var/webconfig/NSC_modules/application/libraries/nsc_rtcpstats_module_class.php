<?php
/** vim: set tabstop=4 softtabstop=4 shiftwidth=4 textwidth=80 smarttab expandtab: **/
/** coding: utf-8: **/
/*
 * Copyright (C) 2012  Sangoma Technologies Corp.
 * All Rights Reserved.
 *
 * Author(s)
 * your name <your_name@sangoma.com>
 *
 * This code is Sangoma Technologies Confidential Property.
 * Use of and access to this code is covered by a previously executed
 * non-disclosure agreement between Sangoma Technologies and the Recipient.
 * This code is being supplied for evaluation purposes only and is not to be
 * used for any other purpose.
*/
/**
 * Network Config wrapper page
 * @author Santiago Tramoyeres Cuesta <scuesta@sangoma.com>
 *         
 */
if (!defined('BASEPATH')) exit('No direct script access allowed');
require_once ('application/helpers/safe_helper.php');

class NSC_rtcpstats_module_class extends Safe_module_class{
    
    private $_query = "";
    const DEFAULT_NUM_ROWS_PER_PAGE = 20;

    public function __construct($app){
        parent::__construct($app->node()->software(),"rtcpmon_stats");       
    }

    public function get_data_settings(){
        return array('stats'=>array(
                                    'description'=>"RTCP Statistics",
                                    'methods'=>array('retrieve'=>array(
                                                                       'name'=>'Retrieve',
                                                                       'description'=>'Retrieve statistics about RTCP monitoring',
                                                                       'request'=>'POST'
                                                                       ),
                                                     'download'=>array(
                                                                       'name'=>'Download',
                                                                       'description'=>'Download csv file with statistics',
                                                                       'request'=>'POST'
                                                                       ),
                                                     )
                                    )
                     );
    }

    private function prepare($data){
        $where = "";;
        $filter = "";
        $order_by = "";
        $having = "";
        $relation = "";
        $value = 0;
        $error = false;
        $relations = array('gt'=>'>=','lt'=>'<=','eq'=>'=');
        $rtp_quality = isset($data['rtp_quality'])? $data['rtp_quality'] : false;
        //$offset = isset($data['offset']) && is_numeric($data['offset'])? $data['offset'] : 0;
        if(isset($data['relation']) && isset($relations[$data['relation']]))
            $relation = $relations[$data['relation']];

        $limit = isset($data['max_per_page']) && is_numeric($data['max_per_page'])? $data['max_per_page'] : self::DEFAULT_NUM_ROWS_PER_PAGE;
        $offset = isset($data['page']) && is_numeric($data['page'])? (($data['page']-1)*$limit) : 0;
        $offset = $offset>0? $offset : 0;
        $select = '`call_leg_unique_id`, `inflow_rtp_flag`, `event_time`, `session_start_time`, `session_stop_time`,';
        $select.= '`local_member_ip`, `remote_member_ip`, `sent_pkt_cnt`, `sent_byte_cnt`, `sender_report_cnt`, `cumulative_lost_cnt`,';
        // Calculate the maximum jitter
        $select.= '`max_inter_arrival_jitter` * 1000 / `sampling_rate` AS `max_jitter`,';
        // Calculate the average jitter
        $select.= '`average_inter_arrival_jitter` * 1000 / `sampling_rate` AS `average_jitter`,';
        // Calculate the percentage of packet loss, note how we add 0.000001 to the count of sent packets, event though is an unsigned
        // this avoids divide by zero when `sent_pkt_cnt` is 0 and at the same time keeps the precision of the resulting calculation
        $select.= '(`cumulative_lost_cnt`/(`sent_pkt_cnt` + 0.000001)) * 100 AS `pkt_loss_percent`';
        if ($data['ip_addr'] != "") $where = 'remote_member_ip = "' . $data['ip_addr'] . '" OR `local_member_ip` = "' . $data['ip_addr'] . '"';
        if ($data['call_leg_unique_id'] != "") {
            if (isset($where) && $where != "") $where.= " AND `";
            $where.= 'call_leg_unique_id` = "' . $data['call_leg_unique_id'] . '"';
        }
        if ($data['session_start_time'] != "") {
            if ($where != "") $where.= " AND `";
            $where.= 'session_start_time` >= "' . $data['session_start_time'] . '"';
        }
        if ($data['session_stop_time'] != "") {
            if (isset($where) && $where != "") $where.= " AND `";
            $where.= 'session_stop_time` <=' . ' "' . $data['session_stop_time'] . '"';
        }
        if ($rtp_quality) {
            if (strtolower($rtp_quality) == 'interarrival jitter' && $data['rtp_value'] != "") {
                $value = $data['rtp_value'] / 100;
                $having = 'average_jitter' . ' ' . $relation . $value;
                $order_by = 'average_jitter DESC, `event_time` DESC';
            } elseif (strtolower($rtp_quality) == 'packet loss percentage' && $data['rtp_value'] != "") {
                $value = $data['rtp_value'];
                $having = 'pkt_loss_percent ' . $relation . ' ' . $value;
                $order_by = 'pkt_loss_percent DESC, `event_time` DESC';
            } else {
                $error = true;
            }
        }

        return array($select,'reports',$where,$order_by,$offset,$limit,$having,$error);
    }

    private function get_num_rows($data,&$db){        
        list($select,$from,$where,$order_by,$offset,$limit,$having,$error) = $this->prepare($data);
        return $error? FALSE : $db->get_select_count($from,$where,'',$select,$having);
    }

    private function exec_query($data,&$db){
        list($select,$from,$where,$order_by,$offset,$limit,$having,$error) = $this->prepare($data);
        return $error? FALSE : $db->select($from,$where,$limit,$offset,$order_by,'',$select,$having);
    }

    public function api_retrieve_stats($name=null,$data=null,&$output=null){
        $db = $this->node()->software()->service('rtcpmon')->db();
        $db->connect();
        
        $records_count = $this->get_num_rows($data,$db);
        $result = $this->exec_query($data,$db);        
        $db->disconnect();
        if($records_count!==FALSE && $result!==FALSE){
            $output['result'] = $result;
            $output['total_rows'] = 0;
            $output['page_rows'] = count($result);
            if($output['page_rows']>0){
                $output['total_rows'] = $records_count;
                $output['page'] = isset($data['page']) && is_numeric($data['page'])? $data['page'] : 1;
                $output['page'] = $output['page']>0? $output['page'] : 1;
                $output['next_page'] = $output['page']+1;
            }
            return true;
        }
        $output['message'] = "Error preparing request";
        return false;            
    }

    public function api_download_stats($name=null,$data=null,&$output=null){
        $db = $this->node()->software()->service('rtcpmon')->db();
        $db->connect();

        $total_rows = $this->get_num_rows($data,$db);
        $data['page'] = 1;
        $data['max_per_page'] = $total_rows;
        $results = $this->exec_query($data,$db);
        $db->disconnect();
        $csv_data_array = array();
        $csv_data_array[] = array('UUID','Direction','Start Time','Stop Time','Local IP','Remote IP','Pkts','Bytes','% Pkt Loss','Max. Jitter','Avg. Jitter');

        foreach ($results as $row) {
            if ($row->inflow_rtp_flag == 1) $inflow = 'Inflow';
            else $inflow = 'Outflow';
            // Check if cdr available for this uuid
            $csv_data_array[] =array(
                    $row->call_leg_unique_id,
                    $inflow,
                    $row->session_start_time,
                    $row->session_stop_time,
                    $row->local_member_ip,
                    $row->remote_member_ip,
                    number_format($row->sent_pkt_cnt) ,
                    number_format($row->sent_byte_cnt) ,
                    number_format($row->pkt_loss_percent) ,
                    number_format($row->max_jitter) ,
                    number_format($row->average_jitter)
            );
        }
        safe_csv_download('rtcpmon_search_results',$csv_data_array);        
    }
}
?>